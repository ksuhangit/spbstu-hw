#ifndef POINT_H
#define POINT_H

#include <iostream>

// структура - точка на плоскости
struct Point { // 20.05.24 переписано было double x, y
    double x;
    double y;
};

#endif
